from django.apps import AppConfig


class MovieshowConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movieshow'
