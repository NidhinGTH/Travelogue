from django.contrib import admin

from movieshow.models import movieshow

# Register your models here.
admin.site.register(movieshow)