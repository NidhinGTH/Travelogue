from django.contrib import admin
from book.models import book
# Register your models here.
admin.site.register(book)